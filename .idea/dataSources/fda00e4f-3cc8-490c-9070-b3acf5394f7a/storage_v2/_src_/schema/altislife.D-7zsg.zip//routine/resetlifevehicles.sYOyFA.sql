create procedure resetLifeVehicles()
  BEGIN
  UPDATE `vehicles` SET `active`= 0;
END;

