create procedure deleteOldContainers()
  BEGIN
  DELETE FROM `containers` WHERE `owned` = 0;
END;

