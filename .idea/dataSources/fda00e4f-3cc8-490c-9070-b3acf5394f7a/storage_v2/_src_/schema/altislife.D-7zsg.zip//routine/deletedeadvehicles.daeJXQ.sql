create procedure deleteDeadVehicles()
  BEGIN
  DELETE FROM `vehicles` WHERE `alive` = 0;
END;

