create procedure deleteOldHouses()
  BEGIN
  DELETE FROM `houses` WHERE `owned` = 0;
END;

