create procedure deleteOldWanted()
  BEGIN
  DELETE FROM `wanted` WHERE `active` = 0;
END;

